$(document).bind("mobileinit", function() {
      $.mobile.page.prototype.options.addBackBtn = true;
	  $.mobile.defaultPageTransition = "none";
	  $.mobile.defaultDialogTransition = "none";
});

$(document).delegate('[data-role="page"]', 'pageinit', function () {
    if (this.id != 'page') {
        var $header = $(this).children('[data-role="header"]');
        if ($header.length) {
            $header.append($('<a />', { class : 'ui-btn-right', href : '#page' }).buttonMarkup({ icon: "home", iconpos : "notext", theme: "b" }));
        }   
    }    
});

var appCache = window.applicationCache;
appCache.update(); // Attempt to update the user's cache.
if (appCache.status == window.applicationCache.UPDATEREADY) {
  appCache.swapCache();  // The fetch was successful, swap in the new cache.
}
if (appCache.status == window.applicationCache.UPDATEREADY) {
  appCache.swapCache();  // The fetch was successful, swap in the new cache.
}
// Check if a new cache is available on page load.
window.addEventListener('load', function(e) {
  window.applicationCache.addEventListener('updateready', function(e) {
    if (window.applicationCache.status == window.applicationCache.UPDATEREADY) {
      // Browser downloaded a new app cache.
      // Swap it in and reload the page to get the new hotness.
      window.applicationCache.swapCache();
      if (confirm('A new version of this site is available. Load it?')) {
        window.location.reload();
      }
    } else {
      // Manifest didn't changed. Nothing new to server.
    }
  }, false);

}, false);
/* end check updated manifest and change */
/* setInterval(function(){cache.update()}, 10000); */
