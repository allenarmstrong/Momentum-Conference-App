$(document).bind("mobileinit", function() {
      $.mobile.page.prototype.options.addBackBtn = true;
	  $.mobile.defaultPageTransition = "none";
	  $.mobile.defaultDialogTransition = "none";
});

$(document).delegate('[data-role="page"]', 'pageinit', function () {
    if (this.id != 'page') {
        var $header = $(this).children('[data-role="header"]');
        if ($header.length) {
            $header.append($('<a />', { class : 'ui-btn-right', href : '#page' }).buttonMarkup({ icon: "home", iconpos : "notext", theme: "b" }));
        }   
    }    
});

	
$('#page').live('pagebeforeshow',function(e,data){    
    $('#test-button').live('click', function(e) {
        $('#confirmDialog').css('overflow-y', 'scroll');        
        $('#confirmDialog').popup('open');
    });    
});

$('#confirmDialog').on({
  popupbeforeposition: function() {
    var maxHeight = $(window).height() - 30;
    $('#confirmDialog').css('max-height', maxHeight + 'px');
  }
});

